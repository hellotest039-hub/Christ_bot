import app
print("✅ Aucune erreur de compilation")
